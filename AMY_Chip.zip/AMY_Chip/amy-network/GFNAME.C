/* get file names (directory) command
 * August 1983, Jack Palevich
 *
 * (passed fspec, buffer, and maxent)
 */

#include "a:stdio.h"
#define SFE 0x11
#define SNE 0x12

char	my_fcb[37],dta[37];

int gfname(dspec, buf, maxent, name_buf, maxnbuf)
char  *dspec, **buf, *name_buf;
int maxent, maxnbuf;
{
    int i, j, result;
    /* set up FCB */
    my_fcb [0] = 0;  /* default drive */
    j = 0;	/* pointer to name buffer */
    strcpy(my_fcb + 1, dspec); /* file name */

    bdos(0x1A, dta);	/* Set disk transfer address */

    result = bdos(SFE, my_fcb);
    if(result != 0)return 0;	/* no entries */

    buf[0] = name_buf;
    convert(dta, buf [0]);
    j = strlen(buf[0]) + 1;

    for(i = 1; i < maxent; i += 1){
	bdos(0x1A, dta);
	result = bdos(SNE, my_fcb);
	if(result != 0)break;
	buf[i] = name_buf + j;
	convert(dta, buf [i]);
	j += strlen(buf[i]) + 1;
	if(j + 13 > maxnbuf)break;
    }
    /* alphabetize the entries. . . . */
    bsort(buf, i);

    return i;
}

convert(fc,b)
char	*fc,*b;
{
    int i,j;
    i = 1;
    j = 0;
    while(i < 9){
	if(fc[i]==' ')break;
	b[j]=fc[i];
	j += 1;
	i += 1;
    }
    b[j]='.'; j += 1;

    i = 9;
    while(i<12){
	if(fc[i]==' ')break;
	b[j]=fc[i];
	j += 1;
	i += 1;
    }
    b[j] = 0;
}

bsort(b, i)
	char **b;
	int i;
{
	int k,j;
	char *t;
	if(i <= 1)return;
	for(k = 0; k < i-1; k += 1)
		for(j = 0; j < i-1; j += 1)
			if( strcmp( b [j], b [j + 1]) > 0){
				t = b[j];
				b[j] = b[j + 1];
				b[j + 1] = t;
			}
 }
